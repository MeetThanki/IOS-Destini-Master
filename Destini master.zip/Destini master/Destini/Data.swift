//
//  Data.swift
//  Destini
//
//  Created by Meet Thanki on 10/07/19.
//  Copyright © 2019 London App Brewery. All rights reserved.
//

import Foundation

class Data{
    
    let questionText : String
    let answer : Bool
    
    init(textdata : String ,correctAnswer: Bool ) {
        questionText = textdata
        answer = correctAnswer
    }
}
